package maze.logic;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class Espada.
 */
public class Espada extends Object implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -104148028924671832L;

	/**
	 * Constructor of the sword.
	 */
	public Espada() {
		super(1, 1);
	}
}
